import { AsyncExport } from '../exports/async-export.decorator';
import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Res,
  BadRequestException,
  UseGuards,
} from '@nestjs/common';
import { Req } from '@nestjs/common';
import type { Response } from 'express';
import { BoqService } from './boq.service';
import { BoqExportService, PdfVariant } from './boq-export.service';
import { CreateBoqDto } from './dto/create-boq.dto';
import { UpdateBoqDto } from './dto/update-boq.dto';
import {
  CreateBoqCategoryDto,
  UpdateBoqCategoryDto,
} from './dto/create-boq-category.dto';
import { CreateBoqItemDto, UpdateBoqItemDto } from './dto/create-boq-item.dto';
import { CreateBoqMiscellaneousDto } from './dto/create-boq-miscellaneous.dto';
import { UpdateBoqMiscellaneousDto } from './dto/update-boq-miscellaneous.dto';
import { ReorderMiscellaneousDto } from './dto/reorder-miscellaneous.dto';
import { ReorderItemsDto } from './dto/reorder-items.dto';
import { BulkUpdateItemsDto } from './dto/bulk-update-items.dto';
import {
  ApproveBoqDto,
  DuplicateVersionDto,
  SubmitForApprovalDto,
} from './dto/boq-workflow.dto';
import { CurrentUser } from '@/common/decorator/current-user.decorator';
import { RequirePermission } from '@/common/decorator/require-permission.decorator';
import { JwtAuthGuard } from '@/common/guards/jwt-auth-guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { User } from '@/modules/users/models/user.model';
import { BoqDashboardService } from './boq-dashboard.service';
import { ApplyTermsDto } from '../metas/dto/apply-terms.dto';

const PDF_VARIANTS: readonly PdfVariant[] = [
  'internal',
  'client',
  'quantity_only',
  'vendor_enquiry',
];

function parsePdfVariant(value: string | undefined): PdfVariant {
  if (!value) return 'internal';
  if ((PDF_VARIANTS as readonly string[]).includes(value)) {
    return value as PdfVariant;
  }
  throw new BadRequestException(
    `Invalid variant "${value}". Expected one of: ${PDF_VARIANTS.join(', ')}`,
  );
}

@Controller('boqs')
export class BoqController {
  constructor(
    private readonly boqService: BoqService,
    private readonly exportService: BoqExportService,
    private readonly dashboardService: BoqDashboardService,
  ) {}

  // ==================== DASHBOARD (static routes first) ====================
  @RequirePermission('boq:read')
  @Get('summary')
  getSummary() {
    return this.dashboardService.getSummary();
  }

  @RequirePermission('boq:read')
  @Get('productivity')
  getProductivity() {
    return this.dashboardService.getProductivity();
  }

  @RequirePermission('boq:read')
  @Get('project-wise')
  getProjectWise() {
    return this.dashboardService.getProjectWise();
  }

  @RequirePermission('boq:read')
  @Get('value-trend')
  getValueTrend(@Query('months') months?: string) {
    return this.dashboardService.getValueTrend(months ? Number(months) : 6);
  }

  @RequirePermission('boq:read')
  @Get('monthly-volume')
  getMonthlyVolume(@Query('months') months?: string) {
    return this.dashboardService.getMonthlyVolume(months ? Number(months) : 6);
  }

  @RequirePermission('boq:read')
  @Get('status-mix')
  getStatusMix() {
    return this.dashboardService.getStatusMix();
  }

  @RequirePermission('boq:read')
  @Get('recently-edited')
  getRecentlyEdited(@Query('limit') limit?: string) {
    return this.dashboardService.getRecentlyEdited(limit ? Number(limit) : 5);
  }

  // ==================== LIST & CRUD ====================
  @RequirePermission('boq:read')
  @Get()
  findAll(
    @Query('project_id') projectId?: string,
    @Query('status') status?: string,
    @Query('q') q?: string,
  ) {
    return this.boqService.findAll(
      projectId,
      status || undefined,
      q || undefined,
    );
  }

  // ==================== VERSION & WORKFLOW ROUTES (more specific first) ====================

  // Version history
  @RequirePermission('boq:read')
  @Get(':id/versions')
  getVersionHistory(@Param('id') id: string) {
    return this.boqService.getVersionHistory(id);
  }

  // Compare versions
  @RequirePermission('boq:read')
  @Get(':id/compare')
  compare(@Param('id') id: string, @Query('vs') vs: string) {
    if (!vs) {
      throw new BadRequestException('vs query param is required');
    }
    return this.boqService.compareVersions(id, vs);
  }

  @RequirePermission('boq:create')
  @Post('combine')
  async combine(@Body() dto: { boqIds: string[]; title?: string }, @Req() req) {
    return this.boqService.combineBoqs(dto, req.user?.id);
  }
  // Rename version (global versionId route)
  @RequirePermission('boq:update')
  @Patch('versions/:versionId')
  renameVersion(
    @Param('versionId') versionId: string,
    @Body('version_name') versionName: string,
  ) {
    if (!versionName?.trim()) {
      throw new BadRequestException('version_name is required');
    }
    return this.boqService.renameVersion(versionId, versionName);
  }

  // Workflow
  @Post(':id/submit-for-approval')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @RequirePermission('boq:submit')
  submitForApproval(
    @Param('id') id: string,
    @Body() dto: SubmitForApprovalDto,
    @CurrentUser() user?: User,
  ) {
    return this.boqService.submitForApproval(id, dto, user?.id);
  }

  @Post(':id/approve')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @RequirePermission('boq:approve')
  approve(
    @Param('id') id: string,
    @Body() dto: ApproveBoqDto,
    @CurrentUser() user?: User,
  ) {
    return this.boqService.approve(id, dto, user?.id);
  }

  @RequirePermission('boq:create')
  @Post(':id/duplicate-version')
  duplicateVersion(
    @Param('id') id: string,
    @Body() dto: DuplicateVersionDto,
    @CurrentUser() user?: User,
  ) {
    return this.boqService.duplicateVersion(id, dto, user?.id);
  }

  @RequirePermission('boq:create')
  @Post(':id/new-version')
  newVersion(@Param('id') id: string, @CurrentUser() user?: User) {
    return this.boqService.newVersion(id, user?.id);
  }

  // ==================== SINGLE BOQ CRUD (general :id route — keep near the end) ====================
  @RequirePermission('boq:read')
  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.boqService.findOne(id);
  }

  @RequirePermission('boq:create')
  @Post()
  create(@Body() dto: CreateBoqDto, @CurrentUser() user?: User) {
    return this.boqService.create(dto, user?.id);
  }

  @RequirePermission('boq:update')
  @Patch(':id')
  update(
    @Param('id') id: string,
    @Body() dto: UpdateBoqDto,
    @CurrentUser() user?: User,
  ) {
    return this.boqService.update(id, dto, user?.id);
  }

  @RequirePermission('boq:delete')
  @Delete(':id')
  remove(@Param('id') id: string, @CurrentUser() user?: User) {
    return this.boqService.remove(id, user?.id);
  }

  // ==================== CATEGORIES & ITEMS ====================
  @RequirePermission('boq:create')
  @Post(':id/categories')
  addCategory(
    @Param('id') id: string,
    @Body()
    dto: CreateBoqCategoryDto,
    @CurrentUser() user?: User,
  ) {
    return this.boqService.addCategory(id, dto, user?.id);
  }

  @RequirePermission('boq:update')
  @Patch(':id/terms')
  applyTerms(
    @Param('id') id: string,
    @Body() dto: ApplyTermsDto,
    @Req() req: any,
  ) {
    return this.boqService.applyTerms(id, dto, req.user?.id);
  }
  @RequirePermission('boq:update')
  @Patch(':id/categories/:categoryId')
  updateCategory(
    @Param('id') id: string,
    @Param('categoryId') categoryId: string,
    @Body() dto: UpdateBoqCategoryDto,
  ) {
    return this.boqService.updateCategory(id, categoryId, dto);
  }

  @RequirePermission('boq:delete')
  @Delete(':id/categories/:categoryId')
  removeCategory(
    @Param('id') id: string,
    @Param('categoryId') categoryId: string,
    @CurrentUser() user?: User,
  ) {
    return this.boqService.removeCategory(id, categoryId, user?.id);
  }

  @RequirePermission('boq:create')
  @Post(':id/categories/:categoryId/items')
  addItem(
    @Param('id') id: string,
    @Param('categoryId') categoryId: string,
    @Body() dto: Omit<CreateBoqItemDto, 'boq_category_id'>,
    @CurrentUser() user?: User,
  ) {
    return this.boqService.addItem(
      id,
      { ...dto, boq_category_id: categoryId },
      user?.id,
    );
  }

  @RequirePermission('boq:update')
  @Patch(':id/items/:itemId')
  updateItem(
    @Param('id') id: string,
    @Param('itemId') itemId: string,
    @Body() dto: UpdateBoqItemDto & { hidden?: boolean },
    @CurrentUser() user?: User,
  ) {
    return this.boqService.updateItem(id, itemId, dto, user?.id);
  }

  @RequirePermission('boq:delete')
  @Delete(':id/items/:itemId')
  removeItem(
    @Param('id') id: string,
    @Param('itemId') itemId: string,
    @CurrentUser() user?: User,
  ) {
    return this.boqService.removeItem(id, itemId, user?.id);
  }

  @RequirePermission('boq:update')
  @Post(':id/items/reorder')
  reorderItems(
    @Param('id') id: string,
    @Body() dto: ReorderItemsDto,
    @CurrentUser() user?: User,
  ) {
    return this.boqService.reorderItems(id, dto, user?.id);
  }

  @RequirePermission('boq:update')
  @Post(':id/items/bulk')
  bulkUpdateItems(
    @Param('id') id: string,
    @Body() dto: BulkUpdateItemsDto,
    @CurrentUser() user?: User,
  ) {
    return this.boqService.bulkUpdateItems(id, dto, user?.id);
  }

  // ==================== MISCELLANEOUS ====================
  // Free-form named financial entries (e.g. "Contingency", "Mobilization
  // charge") that don't fit the category/item structure. Their sum is
  // exposed as misc_amount on the BOQ payload — see
  // BoqService.withComputedTotals.

  // NOTE: registered after '/items/*' and before the reorder route so
  // ':miscId' below never shadows a more specific path.
  @RequirePermission('boq:create')
  @Post(':id/miscellaneous')
  addMiscellaneous(
    @Param('id') id: string,
    @Body() dto: CreateBoqMiscellaneousDto,
    @CurrentUser() user?: User,
  ) {
    return this.boqService.addMiscellaneous(id, dto, user?.id);
  }

  @RequirePermission('boq:update')
  @Post(':id/miscellaneous/reorder')
  reorderMiscellaneous(
    @Param('id') id: string,
    @Body() dto: ReorderMiscellaneousDto,
    @CurrentUser() user?: User,
  ) {
    return this.boqService.reorderMiscellaneous(id, dto.ordered_ids, user?.id);
  }

  @RequirePermission('boq:update')
  @Patch(':id/miscellaneous/:miscId')
  updateMiscellaneous(
    @Param('id') id: string,
    @Param('miscId') miscId: string,
    @Body() dto: UpdateBoqMiscellaneousDto,
    @CurrentUser() user?: User,
  ) {
    return this.boqService.updateMiscellaneous(id, miscId, dto, user?.id);
  }

  @RequirePermission('boq:delete')
  @Delete(':id/miscellaneous/:miscId')
  removeMiscellaneous(
    @Param('id') id: string,
    @Param('miscId') miscId: string,
    @CurrentUser() user?: User,
  ) {
    return this.boqService.removeMiscellaneous(id, miscId, user?.id);
  }

  // ==================== EXPORT ====================
  @AsyncExport('boq-excel')
  @RequirePermission('boq:export')
  @Get(':id/export/excel')
  async exportExcel(@Param('id') id: string, @Res() res: Response) {
    const { buffer, filename } = await this.exportService.toExcel(id);
    res.set({
      'Content-Type':
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="${filename}"`,
    });
    res.send(buffer);
  }

  /**
   * Legacy server-rendered (puppeteer) BOQ PDF in the old layout. The app no longer calls it:
   * downloads and the copy attached on approval are produced client-side with the shared
   * print kit (components/commerce-documents/BoqDocument). Kept for API compatibility only.
   */
  @AsyncExport('boq-pdf')
  @RequirePermission('boq:export')
  @Post(':id/export/pdf')
  async exportPdf(
    @Param('id') id: string,
    @Body('variant') variant: string,
    @Res() res: Response,
  ) {
    const { buffer, filename } = await this.exportService.toPdf(
      id,
      parsePdfVariant(variant),
    );
    res.set({
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="${filename}"`,
    });
    res.send(buffer);
  }

  @AsyncExport('boq-thumbnail')
  @RequirePermission('boq:export')
  @Post(':id/export/pdf-thumbnail')
  async exportPdfThumbnail(
    @Param('id') id: string,
    @Query('variant') variant: string,
    @Res() res: Response,
  ) {
    const buffer = await this.exportService.pageOneThumbnail(
      id,
      parsePdfVariant(variant),
    );
    res.set({ 'Content-Type': 'image/png' });
    res.send(buffer);
  }
}

// Catalog Controller (unchanged — it's correctly separated)
@Controller('boq-catalog')
export class BoqCatalogController {
  constructor(private readonly boqService: BoqService) {}

  @RequirePermission('boq-catalog:read')
  @Get()
  getCatalog() {
    return this.boqService.getCatalog();
  }
}
