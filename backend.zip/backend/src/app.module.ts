import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { SequelizeModule } from '@nestjs/sequelize';
import { SequelizeModuleOptions } from '@nestjs/sequelize';

import databaseConfig from './config/database.config';

import { AppController } from './app.controller';
import { AppService } from './app.service';

// RBAC / Auth
import { AuthModule } from './modules/auth/auth.module';
import { RolesModule } from './modules/rbac/rbac.module';
import { AppsModule } from './modules/rbac/app.module';

// Core
import { UsersModule } from './modules/users/users.module';
import { SettingsModule } from './modules/settings/settings.module';
import { ProjectsModule } from './modules/projects/projects.module';
import { ClientsModule } from './modules/clients/clients.module';
import { VendorsModule } from './modules/vendors/vendors.module';

// Engagement
import { ActivityLogsModule } from './modules/engagement/activity-logs.module';
import { NotificationsModule } from './modules/engagement/notifications.module';

// Quotations / BOQ
import { QuotationsModule } from './modules/quotations/quotations.module';

import { BoqModule } from './modules/boqs/boq.module';

// Meta
import { UnitsModule } from './modules/metas/units.module';
import { TermsModule } from './modules/metas/terms.module';

// Documents
import { DocumentsModule } from './modules/documents/document.module';
import { SharedProjectDataModule } from './modules/documents/shared-project-data.module';
import { DrawingsModule } from './modules/documents/drawing.module';

// Project / Site
import { ProjectBriefsModule } from './modules/brief/brief.module';
import { SiteRecceModule } from './modules/reki/reki.module';
import { TasksModule } from './modules/tasks/task.module';
import { CalendarModule } from './modules/calendar/calendar.module';
import { DashboardsModule } from './modules/dashboard/dashboard.module';
import { LeadsModule } from './modules/leads/leads.module';

// Infrastructure
import { CdnModule } from './modules/cdn/cdn.module';
import { SearchModule } from './modules/search/search.module';

// Reports
import { ReportsModule } from './modules/reports/reports.module';
import { TeamModule } from './modules/users/team.module';
import { PlanOfActionsModule } from './modules/plan-of-action/plan-of-actions.module';
import { PaymentSchedulesModule } from './modules/payments/payment-schedule.module';
import { ProcessWorkflowModule } from './modules/process-workflow/process-workflow.module';
import { SiteOperationsModule } from './modules/site-operations/site-operations.module';
import { MaterialProcurementModule } from './modules/material-procurement/material-procurement.module';
import { ScopeOfWorkModule } from './modules/scope-of-work/scope-of-work.module';
import { BudgetEstimateModule } from './modules/budget-estimate/budget-estimate.module';
import { BudgetGuideModule } from './modules/budget-guide/budget-guide.module';
import { BusinessProposalsModule } from './modules/business-proposals/business-proposals.module';
import { GatesModule } from './modules/gates/gates.module';
import { ZohoModule } from './modules/zoho/zoho.module';
import { MicrosoftModule } from './modules/microsoft/microsoft.module';
import { GoogleModule } from './modules/google/google.module';
import { AutomationModule } from './modules/automation/automation.module';
import { ClientPortalModule } from './modules/client-portal/client-portal.module';
import { ProjectPlannerModule } from './modules/projects/project-planner.module';
import { WorkspaceModule } from './modules/workspace/workspace.module';
import { SyncModule } from './modules/sync/sync.module';
import { HttpSecurityModule } from './common/security/http-security.module';
import { ExportJobsModule } from './modules/exports/export-jobs.module';

@Module({
  imports: [
    // ============================================================
    // Configuration
    // ============================================================
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
      load: [databaseConfig],
    }),
    HttpSecurityModule,
    ExportJobsModule,

    // ============================================================
    // Database
    // ============================================================
    SequelizeModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService): SequelizeModuleOptions =>
        config.getOrThrow<SequelizeModuleOptions>('database'),
    }),

    // ============================================================
    // Authentication / RBAC
    // ============================================================
    AuthModule,
    RolesModule,
    AppsModule,

    // ============================================================
    // Core
    // ============================================================
    UsersModule,
    TeamModule,
    SettingsModule,
    ProjectsModule,
    ClientsModule,
    ProjectPlannerModule,
    WorkspaceModule,
    VendorsModule,
    PlanOfActionsModule,
    PaymentSchedulesModule,
    // ============================================================
    // Engagement
    // ============================================================
    ActivityLogsModule,
    NotificationsModule,
    GatesModule,
    // ============================================================
    // Quotations / BOQ
    // ============================================================
    QuotationsModule,

    BoqModule,

    // ============================================================
    // Meta
    // ============================================================
    UnitsModule,
    TermsModule,

    // ============================================================
    // Documents
    // ============================================================
    DocumentsModule,
    SharedProjectDataModule,
    DrawingsModule,
    SyncModule,
    // ============================================================
    // Project / Site
    // ============================================================
    ProjectBriefsModule,
    SiteRecceModule,
    ScopeOfWorkModule,
    TasksModule,
    CalendarModule,
    DashboardsModule,
    LeadsModule,
    BudgetEstimateModule,
    BudgetGuideModule,
    BusinessProposalsModule,
    // ============================================================
    // Infrastructure
    // ============================================================
    CdnModule,
    SearchModule,
    ProcessWorkflowModule,
    SiteOperationsModule,
    MaterialProcurementModule,
    // ============================================================
    // Reports
    // ============================================================
    ReportsModule,
    ZohoModule,
    MicrosoftModule,
    GoogleModule,
    AutomationModule,
    ClientPortalModule,
  ],

  controllers: [AppController],

  providers: [AppService],
})
export class AppModule {}
