import AppLayout from "@/layouts/AppLayout";
import { Navigate } from "react-router-dom";
import PaymentSchedulePage from "../../pages/payment-schedule/paymentSchedulePage";
import PaymentScheduleList from "@/pages/payment-schedule/PaymentScheduleList";
import { PaymentScheduleForm } from "@/pages/payment-schedule/PaymentScheduleForm";
import BudgetEstimateForm from "../../pages/budget-estimate/BudgetEstimateForm";
import BudgetEstimateView from "../../pages/budget-estimate/BudgetEstimatesView";
import LedgerList from "../../pages/LedgerList";
import BoqDashboard from "@/pages/boq/BoqDashboard";
import BoqNew from "@/pages/boq/BoqNew";
import BoqTemplatesList from "@/pages/boq/BoqTemplatesList";
import BoqTemplateNew from "@/pages/boq/BoqTemplateNew";
import BoqTemplateEditor from "@/pages/boq/BoqTemplateEditor";
import BoqLibraryPage from "@/pages/boq/BoqLibraryPage";
import BoqActivityPage from "@/pages/boq/BoqActivitypage";
import BoqVersions from "@/pages/boq/BoqVersions";
import BoqWorkspace from "@/pages/boq/BoqWorkspace";
import BoqPreview from "@/pages/boq/BoqPreview";
import BudgetGuideList from "@/pages/budget-guide/BudgetGuideList";
import BudgetGuideEditor from "@/pages/budget-guide/BudgetGuideEditor";
import BudgetGuidePreview from "@/pages/budget-guide/BudgetGuidePreview";
export const ledgerRoutes = [
  {
    type: "layout",
    path: "/ledger",
    layout: AppLayout,
    layoutProps: {
      app: "ledger",
    },

    dynamicSections: {
      appKey: "ledger",

      exclude: [
        "ledger",
        "payment-schedules/all",
        "aggrements/all",
        "edit-dashboard",
        // "roles" / "activity" fall through to SectionPage like every other app
      ],
    },

    children: [
      // ============================================================
      // LEDGER
      // ============================================================

      {
        index: true,
        element: <Navigate to="/build" replace />,
      },
      {
        path: "/ledger/all",
        element: <LedgerList />,
      },
      // ============================================================
      // DOCUMENTS
      // ============================================================

      {
        path: "payment-schedule/all",
        element: <PaymentScheduleList />,
      },
      {
        path: "payment-schedule/:scheduleId",
        element: <PaymentSchedulePage />,
      },
      {
        path: "forms/payment-schedule",
        element: <PaymentScheduleForm />,
      },
      {
        path: "forms/payment-schedule/:id/edit",
        element: <PaymentScheduleForm />,
      },
      { path: "budget-guides/all", element: <BudgetGuideList /> },
      { path: "budget-guides/new", element: <BudgetGuideEditor /> },
      { path: "budget-guides/:id/edit", element: <BudgetGuideEditor /> },
      {
        path: "forms/budget-estimate",
        element: <BudgetEstimateForm />,
      },
      {
        path: "forms/budget-estimate/:id/edit",
        element: <BudgetEstimateForm />,
      },
      {
        path: "budget-estimate/:id",
        element: <BudgetEstimateView />,
      },
      { path: "boq/all", element: <BoqDashboard /> },
      { path: "boq/new", element: <BoqNew /> },
      { path: "boq/templates", element: <BoqTemplatesList /> },
      { path: "boq/template/new", element: <BoqTemplateNew /> },
      { path: "boq/template/:id/editor", element: <BoqTemplateEditor /> },
      { path: "boq/rate-and-item-library", element: <BoqLibraryPage /> },
      { path: "boq/activity", element: <BoqActivityPage /> },
      { path: "boq/:id/versions", element: <BoqVersions /> },
      // Document views sit in the shell (global top bar, sidebar, breadcrumb).
      { path: "boq/:id/preview", element: <BoqPreview /> },
      { path: "budget-guides/:id", element: <BudgetGuidePreview /> },
    ],
  },
  // These live outside the AppLayout shell (full-bleed workspace views)
  { path: "/ledger/boq/:id", element: <BoqWorkspace /> },
];

export default ledgerRoutes;
