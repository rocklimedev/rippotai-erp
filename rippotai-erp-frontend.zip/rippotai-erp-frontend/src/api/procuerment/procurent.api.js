import { baseApi } from "../../store/baseApi";

export const procurementApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    // Material-requirement CRUD lives in material-requirement.api.js and
    // inventory transactions in inventory.api.js (duplicates here clashed).
    // =====================================================
    // MATERIAL REQUIREMENTS
    // =====================================================

    // =====================================================
    // SAMPLE BOARDS
    // =====================================================

    createSampleBoard: builder.mutation({
      query: (body) => ({
        url: "/procurement/sample-boards",
        method: "POST",
        body,
      }),
      invalidatesTags: ["SampleBoard"],
    }),

    getSampleBoardsForRequirement: builder.query({
      query: (materialRequirementId) =>
        `/procurement/sample-boards/by-requirement/${materialRequirementId}`,
      providesTags: ["SampleBoard"],
    }),

    getSampleBoard: builder.query({
      query: (id) => `/procurement/sample-boards/${id}`,
      providesTags: ["SampleBoard"],
    }),

    approveSampleBoard: builder.mutation({
      query: ({ id, body }) => ({
        url: `/procurement/sample-boards/${id}/approve`,
        method: "POST",
        body,
      }),
      invalidatesTags: ["SampleBoard"],
    }),

    rejectSampleBoard: builder.mutation({
      query: ({ id, body }) => ({
        url: `/procurement/sample-boards/${id}/reject`,
        method: "POST",
        body,
      }),
      invalidatesTags: ["SampleBoard"],
    }),

    deleteSampleBoard: builder.mutation({
      query: (id) => ({
        url: `/procurement/sample-boards/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["SampleBoard"],
    }),

    // =====================================================
    // MATERIAL RATE SHEETS
    // =====================================================

    createMaterialRateSheet: builder.mutation({
      query: (body) => ({
        url: "/procurement/rate-sheets",
        method: "POST",
        body,
      }),
      invalidatesTags: ["MaterialRateSheet"],
    }),

    getMaterialRateSheetsForRequirement: builder.query({
      query: (materialRequirementId) =>
        `/procurement/rate-sheets/by-requirement/${materialRequirementId}`,
      providesTags: ["MaterialRateSheet"],
    }),

    getMaterialRateSheet: builder.query({
      query: (id) => `/procurement/rate-sheets/${id}`,
      providesTags: ["MaterialRateSheet"],
    }),

    approveMaterialRateSheet: builder.mutation({
      query: ({ id, body }) => ({
        url: `/procurement/rate-sheets/${id}/approve`,
        method: "POST",
        body,
      }),
      invalidatesTags: ["MaterialRateSheet"],
    }),

    rejectMaterialRateSheet: builder.mutation({
      query: ({ id, body }) => ({
        url: `/procurement/rate-sheets/${id}/reject`,
        method: "POST",
        body,
      }),
      invalidatesTags: ["MaterialRateSheet"],
    }),

    deleteMaterialRateSheet: builder.mutation({
      query: (id) => ({
        url: `/procurement/rate-sheets/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["MaterialRateSheet"],
    }),

    // =====================================================
    // MATERIAL ESTIMATES
    // =====================================================

    createMaterialEstimate: builder.mutation({
      query: (body) => ({
        url: "/procurement/estimates",
        method: "POST",
        body,
      }),
      invalidatesTags: ["MaterialEstimate"],
    }),

    getMaterialEstimate: builder.query({
      query: (id) => `/procurement/estimates/${id}`,
      providesTags: ["MaterialEstimate"],
    }),

    getMaterialEstimatesForRequirement: builder.query({
      query: (materialRequirementId) =>
        `/procurement/estimates/by-requirement/${materialRequirementId}`,
      providesTags: ["MaterialEstimate"],
    }),

    approveMaterialEstimate: builder.mutation({
      query: ({ id, body }) => ({
        url: `/procurement/estimates/${id}/approve`,
        method: "POST",
        body,
      }),
      invalidatesTags: ["MaterialEstimate"],
    }),

    rejectMaterialEstimate: builder.mutation({
      query: ({ id, body }) => ({
        url: `/procurement/estimates/${id}/reject`,
        method: "POST",
        body,
      }),
      invalidatesTags: ["MaterialEstimate"],
    }),

    // =====================================================
    // MATERIAL QUOTATIONS
    // =====================================================

    createMaterialQuotation: builder.mutation({
      query: (body) => ({
        url: "/procurement/quotations",
        method: "POST",
        body,
      }),
      invalidatesTags: ["MaterialQuotation"],
    }),

    getMaterialQuotations: builder.query({
      query: () => "/procurement/quotations",
      providesTags: ["MaterialQuotation"],
    }),

    getMaterialQuotation: builder.query({
      query: (id) => `/procurement/quotations/${id}`,
      providesTags: ["MaterialQuotation"],
    }),

    sendMaterialQuotation: builder.mutation({
      query: (id) => ({
        url: `/procurement/quotations/${id}/send`,
        method: "POST",
      }),
      invalidatesTags: ["MaterialQuotation"],
    }),

    acceptMaterialQuotation: builder.mutation({
      query: (id) => ({
        url: `/procurement/quotations/${id}/accept`,
        method: "POST",
      }),
      invalidatesTags: ["MaterialQuotation"],
    }),

    rejectMaterialQuotation: builder.mutation({
      query: (id) => ({
        url: `/procurement/quotations/${id}/reject`,
        method: "POST",
      }),
      invalidatesTags: ["MaterialQuotation"],
    }),

    // =====================================================
    // SITE INVENTORY
    // =====================================================

    getSiteInventory: builder.query({
      query: (projectId) => ({
        url: "/procurement/site-inventory",
        params: projectId ? { projectId } : undefined,
      }),
      providesTags: ["SiteInventory"],
    }),

    getSiteInventoryItem: builder.query({
      query: (id) => `/procurement/site-inventory/${id}`,
      providesTags: ["SiteInventory"],
    }),

    recordInventoryTransaction: builder.mutation({
      query: (body) => ({
        url: "/procurement/site-inventory/transactions",
        method: "POST",
        body,
      }),
      invalidatesTags: ["SiteInventory", "InventoryTransaction"],
    }),

    reconcileInventory: builder.query({
      query: ({ purchaseOrderId, poDeliveredTotal }) => ({
        url: `/procurement/site-inventory/reconcile/${purchaseOrderId}`,
        params: {
          poDeliveredTotal,
        },
      }),
      providesTags: ["SiteInventory"],
    }),
  }),

  overrideExisting: false,
});

export const {
  // =====================================================
  // MATERIAL REQUIREMENTS
  // =====================================================


  // =====================================================
  // SAMPLE BOARDS
  // =====================================================

  useCreateSampleBoardMutation,
  useGetSampleBoardsForRequirementQuery,
  useGetSampleBoardQuery,
  useApproveSampleBoardMutation,
  useRejectSampleBoardMutation,
  useDeleteSampleBoardMutation,

  // =====================================================
  // MATERIAL RATE SHEETS
  // =====================================================

  useCreateMaterialRateSheetMutation,
  useGetMaterialRateSheetsForRequirementQuery,
  useGetMaterialRateSheetQuery,
  useApproveMaterialRateSheetMutation,
  useRejectMaterialRateSheetMutation,
  useDeleteMaterialRateSheetMutation,

  // =====================================================
  // MATERIAL ESTIMATES
  // =====================================================

  useCreateMaterialEstimateMutation,
  useGetMaterialEstimateQuery,
  useGetMaterialEstimatesForRequirementQuery,
  useApproveMaterialEstimateMutation,
  useRejectMaterialEstimateMutation,

  // =====================================================
  // MATERIAL QUOTATIONS
  // =====================================================

  useCreateMaterialQuotationMutation,
  useGetMaterialQuotationsQuery,
  useGetMaterialQuotationQuery,
  useSendMaterialQuotationMutation,
  useAcceptMaterialQuotationMutation,
  useRejectMaterialQuotationMutation,

  // =====================================================
  // SITE INVENTORY
  // =====================================================

  useGetSiteInventoryQuery,
  useGetSiteInventoryItemQuery,
  useRecordInventoryTransactionMutation,
  useReconcileInventoryQuery,
} = procurementApi;
