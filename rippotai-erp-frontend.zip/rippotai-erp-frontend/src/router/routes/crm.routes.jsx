import AppLayout from "@/layouts/AppLayout";

import AppDashboard from "@/components/dashboard/AppDashboard";
import BoardView from "@/pages/leads/BoardView";

import ContactsView from "@/pages/leads/ContactsView";
import SiteRecceList from "@/pages/site-recce/SiteRecceList";
import ProjectBriefList from "@/pages/brief/ProjectBriefList";
import PlanOfActionList from "@/pages/plan-of-action/PlanOfActionList";

import ScopeOfWorkList from "@/pages/scope-of-work/ScopeOfWorkList";
import NewLeadPage from "@/pages/leads/NewLeadPage";

import { BriefForm } from "@/pages/brief/BriefForm";
import { SiteRekiForm } from "@/pages/site-recce/SiteRekiForm";
import { PlanOfActionForm } from "@/pages/plan-of-action/PlanOfActionForm";

import { ScopeOfWorkForm } from "@/pages/scope-of-work/ScopeOfWorkForm";

import { SiteRekiView } from "../../pages/site-recce/SiteRekiView";
import { ProjectBriefView } from "../../pages/brief/ProjectBriefView";
import { PlanOfActionView } from "../../pages/plan-of-action/PlanOfActionView";

import { ScopeOfWorkView } from "../../pages/scope-of-work/ScopeOfWorkView";
import BusinessProposalList from "@/pages/business-proposal/BusinessProposalList";
import BusinessProposalView from "@/pages/business-proposal/BusinessProposalView";
import BusinessProposalWorkspace from "@/pages/business-proposal/BusinessProposalWorkspace";
import ProposalBuilder from "../../pages/documents/ProposalBuilder";
import CRMDashboard from "../../pages/dashboard/CRMDashboard";
import ZohoCrmTestConsole from "../../pages/ZohoCrmTester";
export const crmRoutes = [
  {
    type: "layout",
    path: "/crm",
    layout: AppLayout,
    layoutProps: {
      app: "crm",
    },

    dynamicSections: {
      appKey: "crm",

      exclude: [
        "pipeline",
        "leads/new",
        "leads/sources",
        "upload",
        "forms/project-brief",
        "forms/site-reki",
        "forms/plan-of-action",
        "forms/payment-schedule",
        "forms/scope-of-work",
      ],
    },

    children: [
      {
        path: "business-proposal/workspace",
        element: <BusinessProposalWorkspace />,
      },
      {
        path: "business-proposal/:id/workspace",
        element: <BusinessProposalWorkspace />,
      },
      { path: "business-proposal/:id", element: <BusinessProposalView /> },
      // ============================================================
      // CRM DASHBOARD
      // ============================================================

      {
        index: true,
        element: <AppDashboard appKey="crm" />,
      },

      // ============================================================
      // PIPELINE
      // ============================================================

      {
        path: "pipeline",
        element: <BoardView />,
      },

      {
        path: "leads/new",
        element: <NewLeadPage />,
      },

      {
        path: "leads/sources",
        element: <ContactsView />,
      },
      {
        path: "leads/crm",
        element: <ZohoCrmTestConsole />,
      },
      // ============================================================
      // DOCUMENTS
      // ============================================================

      {
        path: "recce/all",
        element: <SiteRecceList />,
      },
      {
        path: "business-proposal/all",
        element: <BusinessProposalList />,
      },

      {
        path: "recce/:id",
        element: <SiteRekiView />,
      },
      {
        path: "recce/:id/edit",
        element: <SiteRekiForm />,
      },
      {
        path: "brief/all",
        element: <ProjectBriefList />,
      },
      {
        path: "brief/:id",
        element: <ProjectBriefView />,
      },
      {
        path: "brief/:id/edit",
        element: <BriefForm />,
      },
      {
        path: "plan-of-action/all",
        element: <PlanOfActionList />,
      },
      {
        path: "plan-of-action/:id",
        element: <PlanOfActionView />,
      },

      {
        path: "scope-of-work/all",
        element: <ScopeOfWorkList />,
      },
      {
        path: "scope-of-work/:id",
        element: <ScopeOfWorkView />,
      },
      {
        path: "forms/project-brief",
        element: <BriefForm />,
      },
      {
        path: "forms/business-proposal",
        element: <BusinessProposalWorkspace />,
      },
      {
        path: "forms/site-reki",
        element: <SiteRekiForm />,
      },

      {
        path: "forms/plan-of-action",
        element: <PlanOfActionForm />,
      },

      {
        path: "forms/scope-of-work",
        element: <ScopeOfWorkForm />,
      },
      {
        path: "forms/scope-of-work/:id/edit",
        element: <ScopeOfWorkForm />,
      },
      {
        path: "forms/plan-of-action/:id/edit",
        element: <PlanOfActionForm />,
      },
    ],
  },
];
