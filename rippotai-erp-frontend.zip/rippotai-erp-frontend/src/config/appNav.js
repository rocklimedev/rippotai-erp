// Universal header nav config: grouped by dropdown label per app.
// Slugs are relative to the app's base route. A slug starting with "/" is
// treated as an absolute path.

export const APP_META = {
  dashboard: {
    name: "Dashboard",
    base: "/dashboard",
    searchPh: "Search applications",
  },

  projects: {
    name: "Projects",
    base: "/projects",
    searchPh: "Search projects, clients, milestones",
  },

  design_studio: {
    name: "Design Studio",
    base: "/design-studio",
    searchPh: "Search drawings, projects, revisions",
  },

  crm: {
    name: "CRM",
    base: "/crm",
    searchPh: "Search CRM",
  },
  ledger: {
    name: "Ledger",
    base: "/ledger",
    searchPh: "Search Ledger",
  },
  siteOperations: {
    name: "Site Operations",
    base: "/site-operations",
    searchPh: "Search reports, visits, QC, mockups, RFIs",
  },
  adminConsole: {
    name: "Admin Console",
    base: "/console",
    searchPh: "Search users, roles, permissions, settings",
  },
  procurement: {
    name: "Procurement",
    base: "/procurement",
    searchPh: "Search materials, requirements, orders",
  },
  inventory: {
    name: "Inventory",
    base: "/inventory",
    searchPh: "Search inventory",
  },
  tasks: {
    name: "Tasks",
    base: "/tasks",
    searchPh: "Search tasks",
  },

  calendar: {
    name: "Calendar",
    base: "/calendar",
    searchPh: "Search events",
  },
  commandCenter: {
    name: "Command Center",
    base: "/command-center",
    searchPh: "Search anything",
  },
  settings: {
    name: "Settings",
    base: "/settings",
    searchPh: "Search settings...",
  },
  automation: {
    name: "Automation",
    base: "/automation",
    searchPh: "Search automation...",
  },
};

// Landing tile order: 7 apps (Clients + Notes removed in Phase A)
// NOTE: "settings" is intentionally excluded — it's not a landing-page app,
// just a registered entry so TopHeader/AppSwitcher config lookups work.
export const LANDING_ORDER = [
  "projects",
  "design_studio",

  "crm",
  "ledger",
  "siteOperations",
  "procurement",
  "inventory",
  "tasks",
  "calendar",
  "commandCenter",
  "adminConsole",
  "automation",
];

const I = (label, slug) => ({ label, slug });

export const APP_MENUS = {
  dashboard: [],

  projects: [
    {
      label: "Clients",
      slug: "/clients",
    },
    {
      label: "Documents",
      items: [
        I("All Documents", "documents/all"),
        I("Project Planner", "planner/list"),
      ],
    },
    {
      label: "Settings",
      items: [
        I("Edit Dashboard", "edit-dashboard"),
        I("Roles and Permissions", "roles"),
        I("Activity", "activity"),
      ],
    },
  ],

  design_studio: [
    {
      label: "Drawings",
      slug: "all",
    },
    {
      label: "Upload",
      slug: "upload",
    },

    {
      label: "Management",
      items: [
        I("Projects", "/projects"),
        I("Activity", "activity"),
        I("Edit Dashboard", "edit-dashboard"),
        I("Roles & Permissions", "roles"),
      ],
    },
  ],
  automation: [
    {
      label: "Automation",
      items: [
        I("Overview", "/automation"),
        I("Rules", "rules"),
        I("Create Rule", "rules/new"),
      ],
    },

    {
      label: "Monitoring",
      items: [
        I("Run Log", "runs"),
        I("Escalations", "escalations"),
        I("Audit Trail", "audit"),
      ],
    },
  ],
  crm: [
    {
      label: "Pipeline",
      slug: "pipeline",
    },
    {
      label: "Sources",
      slug: "leads/sources",
    },
    {
      label: "Documents",
      items: [
        I("Client Brief", "brief/all"),
        I("Site Recce", "recce/all"),
        I("Scope of Work", "scope-of-work/all"),
        I("Plan of Action", "plan-of-action/all"),

        // I("Scope Of Approval", "scope-of-approval/all"),
        // I("Pitch Deck", "pitch-deck/all"),
        I("Business Proposals", "business-proposal/all"),
      ],
    },

    {
      label: "Settings",
      items: [
        I("Projects", "/projects"),
        I("Clients", "/clients"),
        I("Edit Dashboard", "edit-dashboard"),
        I("Roles and Permissions", "roles"),
        I("Activity", "activity"),
      ],
    },
  ],

  adminConsole: [
    {
      label: "Workspace",
      items: [
        I("Client", "clients"),
        I("Users", "users"),
        I("Roles & Permissions", "roles-permissions"),
        I("Project Phases", "project-phases"),
        I("Document Types", "document-types"),
        I("Project Structure", "project-structure"),
        I("Estimate Signature", "estimate-signature"),
      ],
    },

    {
      label: "Administration",
      items: [
        I("Company Profile", "company-profile"),
        I("Terms & Conditions", "terms-and-conditions"),
        I("Super Admin", "super-admin"),
      ],
    },
    // ------------------------------------------------------------
    // Management
    // ------------------------------------------------------------
    {
      label: "Management",
      items: [
        I("Projects", "/projects"),
        I("Activity", "activity"),
        I("Edit Dashboard", "edit-dashboard"),
      ],
    },
  ],

  procurement: [
    // ------------------------------------------------------------
    // Materials
    // ------------------------------------------------------------
    {
      label: "Materials",
      items: [
        I("Requirements", "requirements"),
        I("Vendors", "vendors/directory"),
        I("Procurement Sheet", "material-procurement/list"),
        I("Rate Comparison", "vendors/rate-comparison"),
        I("Rate Sheets", "rate-sheets"),
      ],
    },

    // ------------------------------------------------------------
    // Procurement
    // ------------------------------------------------------------
    {
      label: "Procurement",
      items: [
        I("Estimates", "estimates/all"),
        I("Delivery Challans", "delivery-challans"),
        I("Purchase Orders", "purchase-orders"),
        I("Work Order", "work-order/all"),
      ],
    },

    // ------------------------------------------------------------
    // Management
    // ------------------------------------------------------------
    {
      label: "Management",
      items: [
        I("Projects", "/projects"),
        I("Activity", "activity"),
        I("Edit Dashboard", "edit-dashboard"),
      ],
    },
  ],
  inventory: [
    {
      label: "Documents",
      items: [
        I("Site Inventory", "site-inventory/all"),
        I("Inventory Transactions", "site-inventory/transactions"),
        I("Record Transaction", "site-inventory/transactions/new"),
      ],
    },
    {
      label: "Settings",
      items: [
        I("Edit Dashboard", "edit-dashboard"),
        I("Roles and Permissions", "roles"),
        I("Activity", "activity"),
      ],
    },
  ],
  siteOperations: [
    {
      label: "Site Operations",
      items: [
        I("Daily Reports", "daily-reports"),
        I("Admin DPR", "admin-dpr"),
        I("Visit Assignments", "visit-assignments"),
      ],
    },

    {
      label: "Quality & Coordination",
      items: [I("Snag Lists", "snag-lists"), I("Checklists", "checklists")],
    },

    {
      label: "Administration",
      items: [
        I("Activity", "activity"),
        I("Projects", "/projects"),
        I("Edit Dashboard", "edit-dashboard"),
        I("Roles & Permissions", "roles"),
      ],
    },
  ],
  ledger: [
    {
      label: "BOQ",
      slug: "boq/all",
    },

    {
      label: "Management",
      items: [
        I("Rate and Item Library", "boq/rate-and-item-library"),
        I("BOQ Templates", "boq/templates"),
      ],
    },
    {
      label: "Documents",
      items: [
        I("Payment Schedules", "payment-schedule/all"),

        I("Budget Estimates", "budget-estimates/all"),
        I("Budget Guides", "budget-guides/all"),
      ],
    },
    {
      label: "Settings",
      items: [
        I("Projects", "/projects"),
        I("Edit Dashboard", "edit-dashboard"),
        I("Roles and Permissions", "roles"),
        I("Activity", "activity"),
      ],
    },
  ],
  tasks: [
    {
      label: "Tasks",
      items: [
        I("My Tasks", "mine"),
        I("All Tasks", "all"),
        I("Crucial Work", "crucial-work"),
        I("Overdue", "overdue"),
        I("New Task", "new"),
      ],
    },
    {
      label: "Notes",
      slug: "notes",
    },
    {
      label: "Settings",
      items: [
        I("Edit Dashboard", "edit-dashboard"),
        I("Roles and Permissions", "roles"),
        I("Activity", "activity"),
      ],
    },
  ],
  calendar: [
    {
      label: "Calendar",
      items: [I("My Calendar", "mine"), I("Team Calendar", "team")],
    },
    {
      label: "Settings",
      items: [
        I("Edit Dashboard", "edit-dashboard"),
        I("Roles and Permissions", "roles"),
        I("Activity", "activity"),
      ],
    },
  ],
  commandCenter: [
    {
      label: "File Manager",
      slug: "file-manager",
    },
  ],
  settings: [
    {
      label: "Account",
      items: [
        I("Edit Profile", "/settings"),
        I("Security", "security"),
        I("Connectors", "connectors"),
      ],
    },
  ],
};

export function allSlugsFor(app) {
  const menus = APP_MENUS[app] || [];
  const out = [];

  for (const g of menus) {
    // Standalone nav item
    if (g.slug) {
      out.push({
        slug: g.slug,
        label: g.label,
      });
    }

    // Dropdown
    if (Array.isArray(g.items)) {
      for (const it of g.items) {
        out.push({
          slug: it.slug,
          label: it.label,
        });
      }
    }
  }

  return out;
}

export function sectionNameFor(app, slug) {
  for (const g of APP_MENUS[app] || []) {
    if (g.slug === slug) return g.label;
    for (const it of g.items || []) if (it.slug === slug) return it.label;
  }
  return (
    (slug || "")
      .split("-")
      .map((s) => s[0]?.toUpperCase() + s.slice(1))
      .join(" ") || "Section"
  );
}

// Legacy compat
export const APP_NAV = Object.fromEntries(
  Object.entries(APP_MENUS).map(([app, groups]) => [
    app,
    {
      primary: groups[0]?.items || [],
      management: groups.find((g) => g.label === "Management")?.items || [],
      admin: groups.find((g) => g.label === "Settings")?.items || [],
    },
  ]),
);
