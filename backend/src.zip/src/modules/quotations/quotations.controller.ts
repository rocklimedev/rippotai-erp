import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  HttpCode,
  HttpStatus,
  UseGuards,
  BadRequestException,
} from '@nestjs/common';

import { QuotationsService } from './quotations.service';
import { QuotationDashboardService } from './quotation-dashboard.service';

import {
  CreateQuotationDto,
  UpdateQuotationDto,
  ReviewQuotationDto,
} from './dto/quotation.dto';
import { CreateQuotationComparisonDto } from './dto/quotation-comparison.dto';

import { QuotationStatus } from '../../common/enums';
import { JwtAuthGuard } from '@/common/guards/jwt-auth-guard';
import { CurrentUser } from '@/common/decorator/current-user.decorator';

@Controller('quotations')
@UseGuards(JwtAuthGuard)
export class QuotationsController {
  constructor(
    private readonly quotationsService: QuotationsService,
    private readonly quotationDashboardService: QuotationDashboardService,
  ) {}

  // =========================
  // CREATE
  // =========================
  @Post()
  create(@Body() dto: CreateQuotationDto, @CurrentUser() user?: any) {
    return this.quotationsService.create(dto, user);
  }

  // =========================
  // GET ALL
  // =========================
  @Get()
  findAll(
    @Query('status') status?: QuotationStatus,
    @Query('project_id') project_id?: string,
    @Query('vendor_id') vendor_id?: string,
    @Query('includeDeleted') includeDeleted?: string,
  ) {
    return this.quotationsService.findAll({
      status,
      project_id,
      vendor_id,
      includeDeleted: includeDeleted === 'true',
    });
  }

  // =========================
  // DASHBOARD
  // =========================
  @Get('summary')
  getSummary() {
    return this.quotationDashboardService.getSummary();
  }

  @Get('project-wise')
  getProjectWise() {
    return this.quotationDashboardService.getProjectWise();
  }

  @Get('expiring-soon')
  getExpiringSoon(@Query('within_days') within_days?: string) {
    return this.quotationDashboardService.getExpiringSoon(
      within_days ? Number(within_days) : 7,
    );
  }

  @Get('boq-variance')
  getBoqVariance() {
    return this.quotationDashboardService.getBoqVariance();
  }

  @Get('value-trend')
  getValueTrend(@Query('months') months?: string) {
    return this.quotationDashboardService.getValueTrend(
      months ? Number(months) : 6,
    );
  }

  @Get('status-mix')
  getStatusMix() {
    return this.quotationDashboardService.getStatusMix();
  }

  @Get('variation-by-project')
  getVariationByProject(@Query('limit') limit?: string) {
    return this.quotationDashboardService.getVariationByProject(
      limit ? Number(limit) : 6,
    );
  }

  // =========================
  // COMPARISON
  // =========================
  @Get('compare')
  async compare(@Query('ids') ids: string) {
    if (!ids) {
      throw new BadRequestException('Query parameter "ids" is required');
    }

    const idList = ids
      .split(',')
      .map((id) => id.trim())
      .filter(Boolean);

    return this.quotationsService.compareQuotations(idList);
  }

  @Post('quotation-comparisons')
  saveComparison(
    @Body() dto: CreateQuotationComparisonDto,
    @CurrentUser() user?: any,
  ) {
    return this.quotationsService.saveComparison(dto, user);
  }

  // =========================
  // SINGLE QUOTATION ROUTES
  // =========================
  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.quotationsService.findOne(id);
  }

  @Patch(':id')
  update(
    @Param('id') id: string,
    @Body() dto: UpdateQuotationDto,
    @CurrentUser() user?: any,
  ) {
    return this.quotationsService.update(id, dto, user);
  }

  @Patch(':id/submit')
  submit(
    @Param('id') id: string,
    @Body('submitted_by') submitted_by?: string,
    @CurrentUser() user?: any,
  ) {
    return this.quotationsService.submit(id, submitted_by, user);
  }

  @Patch(':id/approve')
  approve(
    @Param('id') id: string,
    @Body() dto: ReviewQuotationDto,
    @CurrentUser() user?: any,
  ) {
    return this.quotationsService.approve(id, dto, user);
  }

  @Patch(':id/return')
  returnForEditing(
    @Param('id') id: string,
    @Body() dto: ReviewQuotationDto,
    @CurrentUser() user?: any,
  ) {
    return this.quotationsService.returnForEditing(id, dto, user);
  }

  @Patch(':id/decline')
  decline(
    @Param('id') id: string,
    @Body() dto: ReviewQuotationDto,
    @CurrentUser() user?: any,
  ) {
    return this.quotationsService.decline(id, dto, user);
  }

  @Patch(':id/cancel')
  cancel(
    @Param('id') id: string,
    @Body('updated_by') updated_by?: string,
    @CurrentUser() user?: any,
  ) {
    return this.quotationsService.cancel(id, updated_by, user);
  }

  @Patch(':id/restore')
  restore(@Param('id') id: string, @CurrentUser() user?: any) {
    return this.quotationsService.restore(id, user);
  }

  @Post(':id/mark-selected')
  markSelected(
    @Param('id') id: string,
    @Body('remarks') remarks?: string,
    @CurrentUser() user?: any,
  ) {
    return this.quotationsService.markQuotationSelected(id, remarks, user);
  }

  // =========================
  // DELETE
  // =========================
  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  softDelete(
    @Param('id') id: string,
    @Body('deleted_by') deleted_by?: string,
    @CurrentUser() user?: any,
  ) {
    return this.quotationsService.softDelete(id, deleted_by, user);
  }

  @Delete(':id/permanent')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id') id: string) {
    return this.quotationsService.remove(id);
  }
}
